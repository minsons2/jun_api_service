package com.bjc.lcp.app1222.service;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.IService;

import com.bjc.lcp.app1222.entity.AdminEntity;
/**
 * @description 管理员服务层
 * @author Wujun
 * @date 2023-09-05
 */
public interface AdminService extends IService<AdminEntity> {


}
